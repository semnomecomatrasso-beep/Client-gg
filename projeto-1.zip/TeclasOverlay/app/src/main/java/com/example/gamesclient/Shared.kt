package com.example.gamesclient

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

const val MC_PACKAGE = "com.mojang.minecraftpe"

val NEONS = intArrayOf(
    Color.rgb(0, 183, 255),
    Color.rgb(57, 255, 20),
    Color.rgb(180, 76, 255),
    Color.rgb(255, 45, 85)
)
val NEON_NAMES = arrayOf("Azul", "Verde", "Roxo", "Vermelho")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.prefs() = getSharedPreferences("gc", Context.MODE_PRIVATE)

fun Context.neonColor(): Int = NEONS[prefs().getInt("neon", 0) % NEONS.size]

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable {
    val g = GradientDrawable()
    g.cornerRadius = dp(radiusDp).toFloat()
    g.setColor(fill)
    if (stroke != null) g.setStroke(dp(2), stroke)
    return g
}

fun Context.launchMinecraft(): Boolean {
    val i = packageManager.getLaunchIntentForPackage(MC_PACKAGE) ?: return false
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(i)
    return true
}
