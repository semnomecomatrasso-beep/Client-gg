package com.example.gamesclient

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        route(intent.getStringExtra("screen"))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        route(intent.getStringExtra("screen"))
    }

    private fun route(s: String?) {
        when (s) {
            "locais" -> locais()
            "conversor" -> conversor()
            "dicas" -> dicas()
            else -> home()
        }
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // ---------- helpers de interface ----------

    private fun screen(build: LinearLayout.() -> Unit) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(56), dp(24), dp(32))
        col.build()
        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(6, 10, 24), Color.rgb(8, 40, 80))
        )
        sv.addView(col)
        setContentView(sv)
    }

    private fun txt(t: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.WHITE): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.gravity = Gravity.CENTER
        v.setPadding(0, dp(6), 0, dp(6))
        return v
    }

    private fun neonBtn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setTextColor(Color.WHITE)
        b.isAllCaps = false
        b.textSize = 16f
        b.background = rounded(Color.argb(60, 0, 150, 255), 14, neonColor())
        val lp = LinearLayout.LayoutParams(MATCH, dp(54))
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun field(h: String, number: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = h
        e.setHintTextColor(Color.GRAY)
        e.setTextColor(Color.WHITE)
        if (number) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        e.setSingleLine()
        return e
    }

    // ---------- telas ----------

    private fun home() {
        screen {
            val logo = TextView(this@MainActivity)
            logo.text = "G"
            logo.textSize = 56f
            logo.typeface = Typeface.DEFAULT_BOLD
            logo.setTextColor(Color.WHITE)
            logo.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.rgb(0, 110, 255))
            bg.setStroke(dp(3), neonColor())
            logo.background = bg
            val lp = LinearLayout.LayoutParams(dp(110), dp(110))
            lp.bottomMargin = dp(12)
            logo.layoutParams = lp
            addView(logo)

            addView(txt("GAMES CLIENT", 28f, true, neonColor()))
            addView(txt("Launcher para Minecraft", 14f, false, Color.LTGRAY))
            addView(neonBtn("▶  ENTRAR NO MINECRAFT") { entrar() })
            addView(neonBtn("📍  Locais") { locais() })
            addView(neonBtn("🧭  Conversor Overworld ↔ Nether") { conversor() })
            addView(neonBtn("⚡  Dicas de FPS") { dicas() })
            addView(neonBtn("🎨  Cor do neon: ${NEON_NAMES[prefs().getInt("neon", 0) % NEONS.size]}") {
                prefs().edit().putInt("neon", (prefs().getInt("neon", 0) + 1) % NEONS.size).apply()
                home()
            })
            addView(txt("O app não altera o jogo. O Minecraft precisa estar instalado.", 12f, false, Color.GRAY))
        }
    }

    private fun entrar() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Ative \"Exibir sobre outros apps\" e volte")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        if (!launchMinecraft()) toast("Minecraft não encontrado. Instale pela Play Store.")
    }

    private fun loadLocais(): List<String> =
        (prefs().getString("locais", "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun locais() {
        screen {
            addView(txt("📍 Locais", 24f, true))
            val nome = field("Nome (ex: Casa)")
            val cx = field("X", true)
            val cy = field("Y", true)
            val cz = field("Z", true)
            addView(nome); addView(cx); addView(cy); addView(cz)
            addView(neonBtn("Salvar local") {
                val n = nome.text.toString().trim().replace("|", "/")
                if (n.isEmpty()) {
                    toast("Digite um nome")
                    return@neonBtn
                }
                val linha = n + "|" + cx.text + "|" + cy.text + "|" + cz.text
                val atual = prefs().getString("locais", "") ?: ""
                val novo = if (atual.isEmpty()) linha else atual + "\n" + linha
                prefs().edit().putString("locais", novo).apply()
                locais()
            })
            loadLocais().forEachIndexed { i, l ->
                val p = l.split("|")
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                val t = TextView(this@MainActivity)
                t.text = p[0] + "\nX " + p.getOrElse(1) { "" } + "   Y " + p.getOrElse(2) { "" } + "   Z " + p.getOrElse(3) { "" }
                t.setTextColor(Color.WHITE)
                row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
                val del = Button(this@MainActivity)
                del.text = "✕"
                del.setOnClickListener {
                    val lista = loadLocais().toMutableList()
                    lista.removeAt(i)
                    prefs().edit().putString("locais", lista.joinToString("\n")).apply()
                    locais()
                }
                row.addView(del)
                addView(row)
            }
            addView(neonBtn("🎮  Abrir Minecraft") { launchMinecraft() })
            addView(neonBtn("←  Voltar") { home() })
        }
    }

    private fun conversor() {
        screen {
            addView(txt("🧭 Conversor", 24f, true))
            addView(txt("Digite X e Z", 14f, false, Color.LTGRAY))
            val fx = field("X", true)
            val fz = field("Z", true)
            val res = txt("", 18f, true, neonColor())
            addView(fx); addView(fz)
            addView(neonBtn("Overworld → Nether (÷ 8)") {
                val a = fx.text.toString().toLongOrNull()
                val b = fz.text.toString().toLongOrNull()
                if (a == null || b == null) {
                    toast("Digite X e Z")
                    return@neonBtn
                }
                res.text = "Nether: X " + Math.floorDiv(a, 8L) + "   Z " + Math.floorDiv(b, 8L)
            })
            addView(neonBtn("Nether → Overworld (× 8)") {
                val a = fx.text.toString().toLongOrNull()
                val b = fz.text.toString().toLongOrNull()
                if (a == null || b == null) {
                    toast("Digite X e Z")
                    return@neonBtn
                }
                res.text = "Overworld: X " + (a * 8) + "   Z " + (b * 8)
            })
            addView(res)
            addView(neonBtn("🎮  Abrir Minecraft") { launchMinecraft() })
            addView(neonBtn("←  Voltar") { home() })
        }
    }

    private fun dicas() {
        screen {
            addView(txt("⚡ Dicas de FPS", 24f, true))
            val tips = listOf(
                "1. Diminua a distância de renderização em Configurações > Vídeo.",
                "2. Desative efeitos bonitos (céus, folhas, iluminação suave). Os nomes mudam conforme a versão.",
                "3. Use texturas leves, de baixa resolução.",
                "4. Feche outros apps e desligue o modo de economia de bateria.",
                "5. Deixe o celular fresco: calor faz o aparelho reduzir o desempenho.",
                "6. Evite mundos com muitos animais e muitas máquinas ao mesmo tempo.",
                "7. Mantenha o Minecraft atualizado."
            )
            tips.forEach {
                val t = txt(it, 15f)
                t.gravity = Gravity.START
                addView(t)
            }
            addView(neonBtn("🎮  Abrir Minecraft") { launchMinecraft() })
            addView(neonBtn("←  Voltar") { home() })
        }
    }
}
