package com.example.gamesclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class BubbleService : Service() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panel: View? = null
    private var clockView: TextView? = null
    private var swView: TextView? = null
    private var cpsBtn: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var swRunning = false
    private var swStart = 0L
    private var swAccum = 0L
    private var counter = 0
    private var cpsStart = 0L
    private var cpsCount = 0
    private var cpsResult = ""

    private val sizes = intArrayOf(44, 56, 68)
    private val sizeNames = arrayOf("P", "M", "G")
    private val alphas = floatArrayOf(1f, 0.7f, 0.4f)
    private val alphaNames = arrayOf("100%", "70%", "40%")

    private val ticker = object : Runnable {
        override fun run() {
            updateLive()
            handler.postDelayed(this, 100)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildBubble()
        handler.post(ticker)
    }

    private fun startAsForeground() {
        val canal = "games_client"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(canal, "Games Client", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, canal)
            .setContentTitle("Games Client ativo")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- bolinha ----------

    private fun buildBubble() {
        val p = prefs()
        val size = dp(sizes[p.getInt("bsize", 1)])
        bubble = TextView(this)
        bubble.text = "G"
        bubble.textSize = 20f
        bubble.typeface = Typeface.DEFAULT_BOLD
        bubble.gravity = Gravity.CENTER
        bubble.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.rgb(0, 110, 255))
        bg.setStroke(dp(2), neonColor())
        bubble.background = bg
        bubble.alpha = alphas[p.getInt("balpha", 0)]

        bubbleParams = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubbleParams.x = dp(8)
        bubbleParams.y = dp(160)

        val slop = dp(6)
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = bubbleParams.x; sy = bubbleParams.y
                        tx = e.rawX; ty = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx
                        val dy = e.rawY - ty
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            bubbleParams.x = sx + dx.toInt()
                            bubbleParams.y = sy + dy.toInt()
                            wm.updateViewLayout(bubble, bubbleParams)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                    }
                }
                return true
            }
        })
        wm.addView(bubble, bubbleParams)
    }

    private fun applyBubbleStyle() {
        val p = prefs()
        val size = dp(sizes[p.getInt("bsize", 1)])
        bubbleParams.width = size
        bubbleParams.height = size
        bubble.alpha = alphas[p.getInt("balpha", 0)]
        (bubble.background as GradientDrawable).setStroke(dp(2), neonColor())
        wm.updateViewLayout(bubble, bubbleParams)
    }

    // ---------- painel ----------

    private fun togglePanel() {
        if (panel != null) closePanel() else showPanel()
    }

    private fun closePanel() {
        panel?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        panel = null
        clockView = null
        swView = null
        cpsBtn = null
    }

    private fun showPanel() {
        val v = buildPanel()
        val h = (Resources.getSystem().displayMetrics.heightPixels * 0.85f).toInt()
        val lp = WindowManager.LayoutParams(
            dp(270), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        lp.x = 0
        wm.addView(v, lp)
        panel = v
    }

    private fun reopenPanel() {
        closePanel()
        showPanel()
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(dp(4), dp(4), dp(4), dp(4))
        return v
    }

    private fun chip(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER
        v.background = rounded(Color.argb(60, 255, 255, 255), 10)
        v.setPadding(dp(12), dp(8), dp(12), dp(8))
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.setMargins(dp(4), dp(2), dp(4), dp(2))
        v.layoutParams = lp
        v.setOnClickListener { onClick() }
        return v
    }

    private fun opt(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setTextColor(Color.WHITE)
        v.background = rounded(ColorUtils.setAlphaComponent(neonColor(), 50), 10)
        v.setPadding(dp(12), dp(10), dp(12), dp(10))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, dp(3), 0, dp(3))
        v.layoutParams = lp
        v.setOnClickListener { onClick() }
        return v
    }

    private fun sec(t: String): TextView = label(t, 11f, Color.LTGRAY, true)

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        return r
    }

    private fun openApp(screen: String) {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        i.putExtra("screen", screen)
        startActivity(i)
        closePanel()
    }

    private fun buildPanel(): View {
        val neon = neonColor()
        val p = prefs()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = rounded(Color.argb(238, 8, 12, 28), 16, neon)
        box.setPadding(dp(10), dp(8), dp(10), dp(8))

        val head = row()
        head.addView(label("GAMES CLIENT", 15f, neon, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val clock = label("", 12f, Color.LTGRAY, false)
        clockView = clock
        head.addView(clock)
        head.addView(chip("✕") { closePanel() })
        box.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        // --- ferramentas ---
        list.addView(sec("FERRAMENTAS"))
        val sw = label("00:00.0", 20f, Color.WHITE, true)
        swView = sw
        list.addView(sw)
        val swRow = row()
        swRow.addView(chip("▶ / ⏸") {
            val now = SystemClock.uptimeMillis()
            if (swRunning) {
                swAccum += now - swStart
                swRunning = false
            } else {
                swStart = now
                swRunning = true
            }
        })
        swRow.addView(chip("↺ Zerar") {
            swRunning = false
            swAccum = 0L
        })
        list.addView(swRow)

        val cps = opt("👆 Teste de CPS (5 s)") {
            val now = SystemClock.uptimeMillis()
            if (cpsStart == 0L) {
                cpsStart = now
                cpsCount = 1
            } else {
                cpsCount++
            }
        }
        cpsBtn = cps
        list.addView(cps)

        val cv = label(counter.toString(), 20f, Color.WHITE, true)
        val cRow = row()
        cRow.addView(chip("−") { counter--; cv.text = counter.toString() })
        cRow.addView(cv)
        cRow.addView(chip("+") { counter++; cv.text = counter.toString() })
        list.addView(sec("CONTADOR"))
        list.addView(cRow)

        // --- minecraft ---
        list.addView(sec("MINECRAFT"))
        list.addView(opt("📍 Locais") { openApp("locais") })
        list.addView(opt("🧭 Conversor Nether") { openApp("conversor") })
        list.addView(opt("⚡ Dicas de FPS") { openApp("dicas") })
        list.addView(opt("🎮 Abrir Minecraft") {
            launchMinecraft()
            closePanel()
        })

        // --- ajustes ---
        list.addView(sec("AJUSTES DO CLIENT"))
        list.addView(opt("🎨 Cor do neon: " + NEON_NAMES[p.getInt("neon", 0) % NEONS.size]) {
            p.edit().putInt("neon", (p.getInt("neon", 0) + 1) % NEONS.size).apply()
            applyBubbleStyle()
            reopenPanel()
        })
        list.addView(opt("⭕ Tamanho da bolinha: " + sizeNames[p.getInt("bsize", 1)]) {
            p.edit().putInt("bsize", (p.getInt("bsize", 1) + 1) % sizes.size).apply()
            applyBubbleStyle()
            reopenPanel()
        })
        list.addView(opt("👁 Opacidade da bolinha: " + alphaNames[p.getInt("balpha", 0)]) {
            p.edit().putInt("balpha", (p.getInt("balpha", 0) + 1) % alphas.size).apply()
            applyBubbleStyle()
            reopenPanel()
        })
        list.addView(opt("⛔ Fechar Games Client") { stopSelf() })

        val sv = ScrollView(this)
        sv.addView(list)
        box.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return box
    }

    // ---------- atualização ao vivo ----------

    private fun updateLive() {
        val now = SystemClock.uptimeMillis()
        clockView?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

        val sv = swView
        if (sv != null) {
            val t = swAccum + (if (swRunning) now - swStart else 0L)
            val m = t / 60000
            val s = (t / 1000) % 60
            val d = (t / 100) % 10
            sv.text = String.format(Locale.US, "%02d:%02d.%d", m, s, d)
        }

        if (cpsStart != 0L && now - cpsStart >= 5000) {
            cpsResult = String.format(Locale.US, "👆 CPS: %.1f (toque p/ repetir)", cpsCount / 5.0)
            cpsStart = 0L
            cpsCount = 0
        }
        val cb = cpsBtn
        if (cb != null) {
            cb.text = if (cpsStart != 0L) {
                "Toque! " + cpsCount + "  (" + ((5000 - (now - cpsStart)) / 1000 + 1) + "s)"
            } else if (cpsResult.isEmpty()) {
                "👆 Teste de CPS (5 s)"
            } else {
                cpsResult
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        closePanel()
        try { wm.removeView(bubble) } catch (e: Exception) { }
        super.onDestroy()
    }
}
